<footer class="page-footer font-small" >
    <div class="footer-copyright text-center py-3" style="background-color: #f2f2f2;">© 2020 Copyright:
        <a href="#"> CaFFe_Se.com</a>
    </div>
</footer>
