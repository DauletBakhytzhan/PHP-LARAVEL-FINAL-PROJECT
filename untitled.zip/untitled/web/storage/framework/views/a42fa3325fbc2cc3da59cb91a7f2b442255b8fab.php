<?php $__env->startSection('title'); ?>
    О Нас
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="text-center cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
        <h1> Name: <?php echo e($data->name); ?></h1>
        <h1> adress:<?php echo e($data->address); ?></h1>
        <h1><?php echo e($data->city); ?></h1>
        <h1><?php echo e($data->description); ?></h1>
        <h1><?php echo e($data->rating); ?></h1>


    </div>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daulet/PhpstormProjects/untitled/web/resources/views/about.blade.php ENDPATH**/ ?>