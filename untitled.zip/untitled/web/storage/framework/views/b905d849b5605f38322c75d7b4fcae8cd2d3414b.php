<?php $__env->startSection('title'); ?>
    О Нас
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="text-center cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">


        <div class="map" id="app">

            <gmap-map

                :center="{lat:10, lng:10}"
                :zoom="7"
                style="width: 100%; height:320px;"


            ></gmap-map>

        </div>



    </div>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daulet/PhpstormProjects/untitled/web/resources/views/app.blade.php ENDPATH**/ ?>