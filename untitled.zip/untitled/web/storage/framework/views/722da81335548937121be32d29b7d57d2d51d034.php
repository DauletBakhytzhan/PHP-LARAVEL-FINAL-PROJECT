<?php $__env->startSection('title'); ?>
    О Нас
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="container col">
        <div class="row centered-form">
            <div class=""style="margin-left: 330px; ">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">add <small></small></h3>
                    </div>
                    <div class="panel-body">
                        <form action="addkitchen" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="name" id="first_name" class="form-control input-sm" placeholder="Name">
                                    </div>
                                </div>
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="price_for_one" id="last_name" class="form-control input-sm" placeholder="price_for_one">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" name="description"  class="form-control input-sm" placeholder="description">
                            </div>
                            <div class="form-group">
                                <input type="text" name="url"  class="form-control input-sm" placeholder="url">
                            </div>
                            <div class="form-group">
                                <input type="text" name="address"  class="form-control input-sm" placeholder="address">
                            </div>
                            <button type="submit" value="Register" class="btn btn-info btn-block">add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daulet/PhpstormProjects/untitled/web/resources/views/addkitchen.blade.php ENDPATH**/ ?>