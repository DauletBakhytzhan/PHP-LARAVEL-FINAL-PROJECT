<nav class="site-header sticky-top py-1" style="background-color: #f2f2f2;">
    <div class="container d-flex flex-column flex-md-row justify-content-between">
        <a class="py-2" href="<?php echo e(route('home')); ?>" aria-label="Product">
            <i class="fas fa-mug-hot fa-lg mt-0"></i> Caffe SE
        </a>
        <a class="py-2 d-none d-md-inline-block ml-5 mr-5" href="#"></a>
        <a class="py-2 d-none d-md-inline-block ml-5 mr-5" href="#"></a>
        <a class="py-2 d-none d-md-inline-block ml-5 mr-5" href="#"></a>
        <a class="py-2 d-none d-md-inline-block ml-5 mr-5" href="#"></a>
        <a class="py-2 d-none d-md-inline-block" href="<?php echo e(route('review')); ?>">Контакты</a>
        <a class="py-2 d-none d-md-inline-block" href="<?php echo e(route('registration')); ?>">sing up</a>
        <a class="py-2 d-none d-md-inline-block" href="<?php echo e(route('login')); ?>">sing in</a>

        <ul class="navbar-nav mt-2">
            <li class="nav-item active">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button"
                           data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                            Язык
                        </a>

                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="">Қазақша</a>
                            <a class="dropdown-item" href="">English</a>
                            <a class="dropdown-item" href="">Русский</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
































<?php /**PATH /Users/daulet/PhpstormProjects/untitled/web/resources/views/inc/header.blade.php ENDPATH**/ ?>